<?php

namespace VersionPress\Initialization;

class InitializationAbortedException extends \Exception
{

}
